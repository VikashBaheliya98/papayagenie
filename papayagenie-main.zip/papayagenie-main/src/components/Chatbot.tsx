
import React, { useState } from 'react';
import { MessageCircle, X, Send, Bot, User, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showQuestions, setShowQuestions] = useState(true);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi! I'm your PapayaGenie assistant. I can help answer questions about our services. Choose a question below or ask me anything!",
      isUser: false,
      timestamp: new Date()
    }
  ]);

  const predefinedQuestions = [
    "What is our agency?",
    "How do we solve business problems?",
    "What do we offer?",
    "How to connect with us?"
  ];

  const answers = {
    "What is our agency?": "PapayaGenie is a forward-thinking digital agency specializing in innovative web solutions for next-generation businesses. We combine technical expertise with creative vision to deliver exceptional digital experiences using cutting-edge technologies.",
    "How do we solve business problems?": "We solve business problems through comprehensive digital transformation strategies, including market analysis, tech consulting, custom development, and performance optimization to drive growth and innovation.",
    "What do we offer?": "We offer Web Development (React, Next.js), Mobile Development, UI/UX Design, Digital Strategy, Web3 Integration (Smart Contracts, DApps), and Performance Optimization with SEO.",
    "How to connect with us?": "Contact us via email (contact@papayagenie.com), phone (+91 885 156 5920), or our contact form. We're in Delhi, India with 24/7 support and respond within 24 hours."
  };

  const handleQuestionClick = (question: string) => {
    // Hide questions when one is clicked
    setShowQuestions(false);
    
    // Add user question
    const userMessage: Message = {
      id: messages.length + 1,
      text: question,
      isUser: true,
      timestamp: new Date()
    };

    // Add bot response
    const botResponse: Message = {
      id: messages.length + 2,
      text: answers[question as keyof typeof answers],
      isUser: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage, botResponse]);
  };

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
  };

  const toggleQuestions = () => {
    setShowQuestions(!showQuestions);
  };

  return (
    <>
      {/* Chatbot Toggle Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={toggleChatbot}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-neon-blue to-neon-purple hover:from-neon-purple hover:to-neon-pink shadow-lg glow-effect hover:scale-110 transition-all duration-300"
        >
          {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
        </Button>
      </div>

      {/* Chatbot Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 h-96 glass-effect rounded-2xl border border-white/20 dark:border-white/10 glow-effect z-50 flex flex-col animate-scale-in">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-white/20 dark:border-white/10">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-neon-blue to-neon-purple rounded-full flex items-center justify-center">
                <Bot className="h-4 w-4 text-white" />
              </div>
              <span className="font-semibold text-foreground">PapayaGenie Bot</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleChatbot}
              className="p-1 hover:bg-white/10"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start space-x-2 max-w-[80%] ${message.isUser ? 'flex-row-reverse space-x-reverse' : ''}`}>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    message.isUser 
                      ? 'bg-gradient-to-r from-neon-pink to-neon-purple' 
                      : 'bg-gradient-to-r from-neon-blue to-neon-purple'
                  }`}>
                    {message.isUser ? <User className="h-3 w-3 text-white" /> : <Bot className="h-3 w-3 text-white" />}
                  </div>
                  <div className={`px-3 py-2 rounded-lg ${
                    message.isUser 
                      ? 'bg-gradient-to-r from-neon-blue to-neon-purple text-white' 
                      : 'bg-white/10 text-foreground'
                  }`}>
                    <p className="text-sm">{message.text}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Questions Section */}
          <div className="border-t border-white/20 dark:border-white/10">
            {/* Toggle Button */}
            <div className="flex items-center justify-between px-4 py-2">
              <span className="text-sm font-medium text-foreground">Quick Questions</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleQuestions}
                className="p-1 hover:bg-white/10"
              >
                {showQuestions ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </div>

            {/* Questions List */}
            {showQuestions && (
              <div className="px-4 pb-4">
                <div className="grid grid-cols-1 gap-2">
                  {predefinedQuestions.map((question, index) => (
                    <button
                      key={index}
                      onClick={() => handleQuestionClick(question)}
                      className="text-left px-3 py-2 text-sm bg-white/5 hover:bg-white/10 rounded-lg transition-colors duration-200 text-muted-foreground hover:text-foreground"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
