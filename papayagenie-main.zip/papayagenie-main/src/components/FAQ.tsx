
import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ = () => {
  const [openItem, setOpenItem] = useState<number | null>(null);

  const faqItems = [
    {
      question: "What is PapayaGenie?",
      answer: "PapayaGenie is a forward-thinking digital agency that specializes in creating innovative web solutions for the next generation of businesses. We combine technical expertise with creative vision to deliver exceptional digital experiences using cutting-edge technologies like Web3, React, and modern design principles. We're not just another agency - we're your partners in building something extraordinary."
    },
    {
      question: "How do we solve business problems?",
      answer: "We solve business problems through comprehensive digital transformation strategies that align technology with your business objectives. Our approach includes market analysis, tech consulting, custom web development, mobile apps, UI/UX design, partnership development, Web3 integration, and performance optimization to drive growth and innovation. We help you create partnerships that go beyond code—partnerships that transform ideas into impact."
    },
    {
      question: "What services do we offer?",
      answer: "We offer a full range of digital services including: Custom Web Development (React & Next.js, Custom CMS, E-commerce, API Integration), Mobile Development (iOS & Android, React Native, Flutter, Progressive Web Apps), UI/UX Design (User Research, Prototyping, Design Systems, Accessibility), Digital Strategy (Market Analysis, Tech Consulting, Growth Strategy, Digital Marketing), Partnership Development (Startup Partnerships, Enterprise Collaborations, Strategic Alliances, Innovation Networks), Web3 Integration (Smart Contracts, DApp Development, NFT Platforms, Crypto Integration), and Performance Optimization (SEO Optimization, Core Web Vitals, Speed Enhancement, Analytics Setup)."
    },
    {
      question: "How can you connect with us?",
      answer: "You can connect with us through multiple channels: Email us at contact@papayagenie.com, call us at +91 885 156 5920, or fill out our contact form on this page. We're based in Delhi, India and provide 24/7 support and maintenance. We'll get back to you within 24 hours to discuss your project needs and help transform your digital presence."
    },
    {
      question: "Why should you choose PapayaGenie?",
      answer: "Choose PapayaGenie because we offer 24/7 Support & Maintenance, use cutting-edge technologies, provide custom solutions tailored to your needs, and ensure fast delivery. We have completed 50+ projects with 5+ years of experience. We focus on innovation first, have a global reach, and maintain quality-focused approach where every project receives our full attention to detail."
    },
    {
      question: "What makes us different from other agencies?",
      answer: "We're not just another agency - we're your partners in building something extraordinary. Whether you're a startup with a bold vision or an industry leader ready to innovate, we help you create partnerships that go beyond code. We connect startups and industry leaders, fostering partnerships that drive innovation. When technology meets human understanding, that's where magic happens. We make the complex feel effortless and build with heart and precision."
    }
  ];

  const toggleItem = (index: number) => {
    setOpenItem(openItem === index ? null : index);
  };

  return (
    <section id="faq" className="py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-space font-bold mb-6">
            <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
              Frequently Asked Questions
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Find answers to common questions about our services and how we can help transform your business.
          </p>
        </div>

        <div className="space-y-4">
          {faqItems.map((item, index) => (
            <div key={index} className="glass-effect rounded-2xl overflow-hidden glow-effect">
              <button
                onClick={() => toggleItem(index)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-white/5 transition-all duration-300"
              >
                <h3 className="text-lg font-semibold text-foreground pr-4">{item.question}</h3>
                {openItem === index ? (
                  <ChevronUp className="h-5 w-5 text-neon-blue flex-shrink-0" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-neon-blue flex-shrink-0" />
                )}
              </button>
              {openItem === index && (
                <div className="px-6 pb-4 animate-fade-in-up">
                  <p className="text-muted-foreground leading-relaxed">{item.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
