
import React, { useRef } from 'react';
import { Star, ExternalLink, User, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Portfolio = () => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const portfolioItems = [
    {
      id: 1,
      title: "TechStart Dashboard",
      client: "Sarah Johnson",
      company: "TechStart Inc.",
      rating: 5,
      review: "Exceptional work! The team delivered a cutting-edge dashboard that transformed our business operations. The Web3 integration was seamless.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop",
      tags: ["React", "Web3", "Dashboard"],
      link: "#"
    },
    {
      id: 2,
      title: "CryptoTrade Platform",
      client: "Michael Chen",
      company: "CryptoTrade Solutions",
      rating: 5,
      review: "Outstanding development team. They created a robust trading platform with beautiful UI/UX. Highly recommend for any fintech project.",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop",
      tags: ["Next.js", "Blockchain", "Trading"],
      link: "#"
    },
    {
      id: 3,
      title: "NFT Marketplace",
      client: "Emma Rodriguez",
      company: "ArtBlock Studios",
      rating: 4,
      review: "Great experience working with FutureAgency. The NFT marketplace they built exceeded our expectations with its modern design.",
      image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=400&h=300&fit=crop",
      tags: ["NFT", "Ethereum", "Marketplace"],
      link: "#"
    },
    {
      id: 4,
      title: "DeFi Analytics App",
      client: "David Kumar",
      company: "DeFi Analytics",
      rating: 5,
      review: "Professional team that delivered on time. The analytics dashboard is incredibly intuitive and the performance is top-notch.",
      image: "https://images.unsplash.com/photo-1518186285589-2f7649de83e0?w=400&h=300&fit=crop",
      tags: ["DeFi", "Analytics", "React"],
      link: "#"
    },
    {
      id: 5,
      title: "E-commerce Platform",
      client: "Lisa Thompson",
      company: "Fashion Forward",
      rating: 4,
      review: "Fantastic redesign of our e-commerce platform. The new UI increased our conversion rates by 40%. Very satisfied with the results.",
      image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=300&fit=crop",
      tags: ["E-commerce", "UI/UX", "Mobile"],
      link: "#"
    },
    {
      id: 6,
      title: "SaaS Management Tool",
      client: "Robert Wilson",
      company: "CloudSync Pro",
      rating: 5,
      review: "The team understood our vision perfectly. The SaaS platform they built is scalable, efficient, and user-friendly.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop",
      tags: ["SaaS", "Cloud", "Management"],
      link: "#"
    }
  ];

  const renderStars = (rating: number) => {
    return [...Array(5)].map((_, index) => (
      <Star
        key={index}
        className={`h-3 w-3 ${
          index < rating
            ? 'text-yellow-400 fill-yellow-400'
            : 'text-gray-300'
        }`}
      />
    ));
  };

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };

  return (
    <section className="py-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-space font-bold mb-6">
            <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
              Our Proudest Work
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Each project tells a story of partnership, innovation, and transformation. Here's what happens when vision meets execution.
          </p>
        </div>

        {/* Manual Scroll Container */}
        <div className="relative">
          {/* Left Arrow */}
          <Button
            onClick={scrollLeft}
            variant="outline"
            size="icon"
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border-white/20 hover:bg-white/90 dark:hover:bg-slate-700/90"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>

          {/* Right Arrow */}
          <Button
            onClick={scrollRight}
            variant="outline"
            size="icon"
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm border-white/20 hover:bg-white/90 dark:hover:bg-slate-700/90"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>

          {/* Scrollable Container */}
          <div 
            ref={scrollContainerRef}
            className="flex overflow-x-auto space-x-4 px-12 scrollbar-hide"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {portfolioItems.map((item) => (
              <Card
                key={item.id}
                className="min-w-[280px] max-w-[280px] glass-effect glow-effect hover:scale-105 hover:glow-effect transition-all duration-300 cursor-pointer group flex-shrink-0"
              >
                <CardContent className="p-6">
                  {/* Project Image */}
                  <div className="relative mb-4 overflow-hidden rounded-lg">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-32 object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-end p-3">
                      <ExternalLink className="h-4 w-4 text-white" />
                    </div>
                  </div>

                  {/* Project Title */}
                  <h3 className="text-lg font-semibold text-foreground mb-3 line-clamp-1">{item.title}</h3>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {item.tags.slice(0, 3).map((tag, index) => (
                      <span
                        key={index}
                        className="text-xs px-2 py-1 bg-neon-blue/20 text-neon-blue rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Rating */}
                  <div className="flex items-center space-x-1 mb-3">
                    {renderStars(item.rating)}
                    <span className="text-sm text-muted-foreground ml-2">({item.rating}/5)</span>
                  </div>

                  {/* Review */}
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                    "{item.review}"
                  </p>

                  {/* Client Info */}
                  <div className="flex items-center space-x-3 pt-3 border-t border-white/10">
                    <div className="w-8 h-8 bg-gradient-to-r from-neon-blue to-neon-purple rounded-full flex items-center justify-center">
                      <User className="h-4 w-4 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-foreground">{item.client}</div>
                      <div className="text-xs text-muted-foreground line-clamp-1">{item.company}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .line-clamp-1 {
          display: -webkit-box;
          -webkit-line-clamp: 1;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </section>
  );
};

export default Portfolio;
