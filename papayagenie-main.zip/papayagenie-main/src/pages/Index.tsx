import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { Moon, Sun, Menu, X, ChevronDown, Sparkles, Zap, Globe, Smartphone, Code, Palette, ArrowDown, Mail, Phone, MapPin, Send, Bot, Mic, Database, ShoppingCart, TrendingUp, Search, ArrowUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import FAQ from '@/components/FAQ';
import Portfolio from '@/components/Portfolio';
const Index = () => {
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const {
    toast
  } = useToast();

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    whatsapp: '',
    message: ''
  });
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  const scrollToPortfolio = () => {
    document.getElementById('portfolio')?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  const scrollToTop = () => {
    document.getElementById('home')?.scrollIntoView({
      behavior: 'smooth'
    });
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.whatsapp.trim() || !formData.message.trim()) {
      toast({
        title: "Required fields missing",
        description: "Please fill in all required fields: Name, Email, WhatsApp number, and Message.",
        variant: "destructive"
      });
      return;
    }
    setIsSubmitting(true);
    try {
      const {
        data,
        error
      } = await supabase.functions.invoke('send-contact-email', {
        body: {
          name: formData.name,
          email: formData.email,
          whatsapp: formData.whatsapp,
          message: formData.message
        }
      });
      if (error) {
        console.error('Email sending error:', error);
        throw error;
      }
      console.log('Email sent successfully:', data);
      toast({
        title: "Message sent successfully!",
        description: "We'll get back to you within 24 hours."
      });

      // Reset form
      setFormData({
        name: '',
        email: '',
        whatsapp: '',
        message: ''
      });
    } catch (error: any) {
      console.error('Error sending email:', error);
      toast({
        title: "Error sending message",
        description: "Please try again later or contact us directly.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const services = [{
    name: 'Web Development',
    icon: Code,
    description: 'Custom websites and web applications'
  }, {
    name: 'Mobile Apps',
    icon: Smartphone,
    description: 'iOS and Android applications'
  }, {
    name: 'UI/UX Design',
    icon: Palette,
    description: 'User-centered design solutions'
  }, {
    name: 'Digital Strategy',
    icon: Globe,
    description: 'Comprehensive digital transformation'
  }, {
    name: 'E-Commerce',
    icon: ShoppingCart,
    description: 'Online store development and optimization'
  }, {
    name: 'Small Business Growth',
    icon: TrendingUp,
    description: 'Scalable solutions for growing businesses'
  }, {
    name: 'SEO',
    icon: Search,
    description: 'Search engine optimization services'
  }, {
    name: 'Digital Marketing',
    icon: Globe,
    description: 'Complete digital marketing strategies and campaigns'
  }];
  const dropdownItems = {
    services: [{
      name: 'Web Development',
      href: '#services'
    }, {
      name: 'Mobile Development',
      href: '#services'
    }, {
      name: 'UI/UX Design',
      href: '#services'
    }, {
      name: 'Digital Strategy',
      href: '#services'
    }, {
      name: 'E-commerce Solutions',
      href: '#services'
    }],
    solutions: [{
      name: 'Startup Packages',
      href: '#solutions'
    }, {
      name: 'Enterprise Solutions',
      href: '#solutions'
    }, {
      name: 'E-commerce Platforms',
      href: '#solutions'
    }, {
      name: 'Web3 Integration',
      href: '#solutions'
    }]
  };
  return <>
      <Helmet>
        <title>PapayaGenie - Future Ready Digital Solutions | Web Development & Design Agency</title>
        <meta name="description" content="PapayaGenie is a forward-thinking digital agency specializing in Web Development, Mobile Apps, UI/UX Design, and Web3 Integration. We create cutting-edge digital experiences for startups and enterprises in Delhi, India." />
        <meta name="keywords" content="web development, mobile apps, UI/UX design, digital agency, Web3, React, Next.js, Delhi, India, startup solutions, enterprise development" />
        <meta name="author" content="PapayaGenie" />
        <meta name="robots" content="index, follow" />
        
        {/* Open Graph / Facebook */}
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://papayagenie.com/" />
        <meta property="og:title" content="PapayaGenie - Future Ready Digital Solutions" />
        <meta property="og:description" content="We craft cutting-edge web experiences that push the boundaries of innovation, blending Web3 technology with stunning design for the next generation of digital businesses." />
        <meta property="og:image" content="https://papayagenie.com/og-image.jpg" />
        <meta property="og:site_name" content="PapayaGenie" />
        
        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content="https://papayagenie.com/" />
        <meta property="twitter:title" content="PapayaGenie - Future Ready Digital Solutions" />
        <meta property="twitter:description" content="We craft cutting-edge web experiences that push the boundaries of innovation, blending Web3 technology with stunning design." />
        <meta property="twitter:image" content="https://papayagenie.com/og-image.jpg" />
        
        {/* Additional SEO */}
        <meta name="theme-color" content="#3B82F6" />
        <meta name="msapplication-TileColor" content="#3B82F6" />
        <link rel="canonical" href="https://papayagenie.com/" />
        
        {/* Structured Data */}
        <script type="application/ld+json">
          {JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          "name": "PapayaGenie",
          "description": "Forward-thinking digital agency specializing in innovative web solutions",
          "url": "https://papayagenie.com",
          "logo": "https://papayagenie.com/logo.png",
          "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+91-885-156-5920",
            "contactType": "customer service",
            "email": "contact@papayagenie.com"
          },
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "Delhi",
            "addressCountry": "IN"
          },
          "sameAs": ["https://twitter.com/papayagenie", "https://linkedin.com/company/papayagenie"]
        })}
        </script>
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-slate-900 dark:via-slate-800 dark:to-indigo-900 transition-all duration-500">
        
        {/* Navigation */}
        <nav className="fixed top-0 w-full z-50 glass-effect border-b border-white/20 dark:border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              {/* Logo */}
              <div className="flex items-center space-x-2">
                <img src="/lovable-uploads/5a5ea259-9a76-4d9c-a3ca-5d0a03fc07e1.png" alt="PapayaGenie Logo" className="w-8 h-8 rounded-lg object-cover" />
                <span className="text-xl font-space font-bold bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
                  PapayaGenie
                </span>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center space-x-8">
                <a href="#home" className="text-foreground hover:text-neon-blue transition-colors duration-300">
                  Home
                </a>
                
                {/* Services Dropdown */}
                <div className="relative" onMouseEnter={() => setActiveDropdown('services')} onMouseLeave={() => setActiveDropdown(null)}>
                  <button className="flex items-center space-x-1 text-foreground hover:text-neon-blue transition-colors duration-300">
                    <span>Services</span>
                    <ChevronDown className="h-4 w-4" />
                  </button>
                  {activeDropdown === 'services' && <div className="absolute top-full left-0 mt-2 w-56 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md rounded-lg shadow-xl border border-white/20 dark:border-white/10 glow-effect z-50">
                      <div className="p-2">
                        {dropdownItems.services.map((item, index) => <a key={index} href={item.href} className="block px-4 py-2 text-sm text-foreground hover:text-neon-blue hover:bg-white/10 rounded-md transition-all duration-200">
                            {item.name}
                          </a>)}
                      </div>
                    </div>}
                </div>

                {/* Solutions Dropdown */}
                <div className="relative" onMouseEnter={() => setActiveDropdown('solutions')} onMouseLeave={() => setActiveDropdown(null)}>
                  <button className="flex items-center space-x-1 text-foreground hover:text-neon-blue transition-colors duration-300">
                    <span>Solutions</span>
                    <ChevronDown className="h-4 w-4" />
                  </button>
                  {activeDropdown === 'solutions' && <div className="absolute top-full left-0 mt-2 w-56 bg-white/95 dark:bg-slate-800/95 backdrop-blur-md rounded-lg shadow-xl border border-white/20 dark:border-white/10 glow-effect z-50">
                      <div className="p-2">
                        {dropdownItems.solutions.map((item, index) => <a key={index} href={item.href} className="block px-4 py-2 text-sm text-foreground hover:text-neon-blue hover:bg-white/10 rounded-md transition-all duration-200">
                            {item.name}
                          </a>)}
                      </div>
                    </div>}
                </div>

                <a href="#about" className="text-foreground hover:text-neon-blue transition-colors duration-300">
                  About
                </a>
                <a href="#contact" className="text-foreground hover:text-neon-blue transition-colors duration-300">
                  Contact
                </a>
              </div>

              {/* Theme Toggle & Mobile Menu */}
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" onClick={toggleDarkMode} className="p-2 hover:bg-white/10 hover:text-neon-blue transition-all duration-300">
                  {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                </Button>

                {/* Mobile menu button */}
                <Button variant="ghost" size="sm" className="md:hidden p-2 hover:bg-white/10" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                  {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                </Button>
              </div>
            </div>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && <div className="md:hidden glass-effect border-t border-white/20 dark:border-white/10">
              <div className="px-4 pt-2 pb-3 space-y-1">
                <a href="#home" className="block px-3 py-2 text-foreground hover:text-neon-blue transition-colors">
                  Home
                </a>
                <a href="#services" className="block px-3 py-2 text-foreground hover:text-neon-blue transition-colors">
                  Services
                </a>
                <a href="#solutions" className="block px-3 py-2 text-foreground hover:text-neon-blue transition-colors">
                  Solutions
                </a>
                <a href="#about" className="block px-3 py-2 text-foreground hover:text-neon-blue transition-colors">
                  About
                </a>
                <a href="#contact" className="block px-3 py-2 text-foreground hover:text-neon-blue transition-colors">
                  Contact
                </a>
              </div>
            </div>}
        </nav>

        {/* Hero Section */}
        <section id="home" className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <div className="animate-fade-in-up py-[48px]">
              <h1 className="text-4xl sm:text-5xl lg:text-7xl font-space font-bold mb-6">
                <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent animate-neon-glow">Future Ready</span>
                <br />
                <span className="text-foreground">Digital Solutions</span>
              </h1>
              <p className="text-xl sm:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                We craft cutting-edge web experiences that push the boundaries of innovation, 
                blending Web3 technology with stunning design for the next generation of digital businesses.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <Button onClick={scrollToContact} className="px-8 py-6 text-lg font-semibold bg-gradient-to-r from-neon-blue to-neon-purple hover:from-neon-purple hover:to-neon-pink transition-all duration-300 glow-effect hover:scale-105 transform">
                  Get Started
                  <ArrowDown className="ml-2 h-5 w-5" />
                </Button>
                <Button onClick={scrollToPortfolio} variant="outline" className="px-8 py-6 text-lg font-semibold glass-effect neon-border hover:bg-white/10 hover:scale-105 transform transition-all duration-300">
                  View Our Work
                </Button>
              </div>
            </div>

            {/* Floating Elements */}
            <div className="mt-16 relative">
              <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-neon-blue to-neon-purple rounded-full opacity-20 animate-pulse"></div>
              <div className="absolute top-20 right-20 w-16 h-16 bg-gradient-to-r from-neon-pink to-neon-purple rounded-full opacity-30 animate-bounce"></div>
              <div className="glass-effect rounded-2xl p-8 max-w-4xl mx-auto glow-effect">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {services.map((service, index) => <div key={index} className="text-center group">
                      <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-neon-blue to-neon-purple rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                        <service.icon className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-foreground mb-2">{service.name}</h3>
                      <p className="text-sm text-muted-foreground">{service.description}</p>
                    </div>)}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section id="services" className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-space font-bold mb-6">
                <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
                  What We're All About
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-4xl mx-auto mb-8">
                We're not just another agency. We're your partners in building something extraordinary. 
                Whether you're a startup with a bold vision or an industry leader ready to innovate, 
                we help you create partnerships that go beyond code—partnerships that transform ideas into impact.
              </p>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
                Because when technology meets human understanding, that's where magic happens.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[{
              title: "AI-Powered Support Bots",
              description: "Intelligent chatbots that understand context and provide human-like interactions",
              icon: Bot,
              iconColor: "service-icon-blue"
            }, {
              title: "Voice Assistants",
              description: "Advanced voice recognition and natural language processing for seamless communication",
              icon: Mic,
              iconColor: "service-icon-green"
            }, {
              title: "Custom CRM Systems",
              description: "Tailored customer relationship management with AI-driven insights and automation",
              icon: Database,
              iconColor: "service-icon-purple"
            }, {
              title: "Automation Web Tools",
              description: "Streamline workflows with intelligent automation that adapts to your business needs",
              icon: Zap,
              iconColor: "service-icon-pink"
            }].map((service, index) => <div key={index} className="service-card group">
                  <div className={`w-16 h-16 ${service.iconColor} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <service.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-3">{service.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{service.description}</p>
                </div>)}
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-space font-bold mb-6">
                  <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
                    About PapayaGenie
                  </span>
                </h2>
                <p className="text-lg text-muted-foreground mb-6">
                  We are a forward-thinking digital agency that specializes in creating innovative web solutions 
                  for the next generation of businesses. Our team combines technical expertise with creative vision 
                  to deliver exceptional digital experiences.
                </p>
                <p className="text-lg text-muted-foreground mb-8">
                  From startups to enterprise clients, we help organizations navigate the digital landscape 
                  with cutting-edge technologies, modern design principles, and strategic thinking.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-neon-blue mb-2">50+</div>
                    <div className="text-sm text-muted-foreground">Projects Completed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-neon-purple mb-2">5+</div>
                    <div className="text-sm text-muted-foreground">Years Experience</div>
                  </div>
                </div>
              </div>
              <div className="glass-effect rounded-2xl p-8 glow-effect">
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-neon-blue to-neon-purple rounded-lg flex items-center justify-center">
                      <Zap className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Innovation First</h3>
                      <p className="text-muted-foreground">We stay ahead of the curve with the latest technologies</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-neon-purple to-neon-pink rounded-lg flex items-center justify-center">
                      <Globe className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Global Reach</h3>
                      <p className="text-muted-foreground">Serving clients worldwide with 24/7 support</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-neon-pink to-neon-blue rounded-lg flex items-center justify-center">
                      <Sparkles className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Quality Focused</h3>
                      <p className="text-muted-foreground">Every project receives our full attention to detail</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Portfolio Section */}
        <div id="portfolio">
          <Portfolio />
        </div>

        {/* FAQ Section */}
        <FAQ />

        {/* Contact Section */}
        <section id="contact" className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-space font-bold mb-6">
                <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
                  Get In Touch
                </span>
              </h2>
              <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
                Ready to transform your digital presence? Let's discuss your project and bring your vision to life.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div className="glass-effect rounded-2xl p-8 glow-effect">
                <h3 className="text-2xl font-semibold text-foreground mb-6">Send us a message</h3>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-foreground mb-2">
                      Name *
                    </label>
                    <Input id="name" type="text" required value={formData.name} onChange={e => setFormData({
                    ...formData,
                    name: e.target.value
                  })} className="glass-effect border-white/20 dark:border-white/10 focus:border-neon-blue focus:ring-neon-blue" placeholder="Your full name" disabled={isSubmitting} />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                      Email *
                    </label>
                    <Input id="email" type="email" required value={formData.email} onChange={e => setFormData({
                    ...formData,
                    email: e.target.value
                  })} className="glass-effect border-white/20 dark:border-white/10 focus:border-neon-blue focus:ring-neon-blue" placeholder="your.email@example.com" disabled={isSubmitting} />
                  </div>

                  <div>
                    <label htmlFor="whatsapp" className="block text-sm font-medium text-foreground mb-2">
                      WhatsApp Number *
                    </label>
                    <Input id="whatsapp" type="tel" required value={formData.whatsapp} onChange={e => setFormData({
                    ...formData,
                    whatsapp: e.target.value
                  })} className="glass-effect border-white/20 dark:border-white/10 focus:border-neon-blue focus:ring-neon-blue" disabled={isSubmitting} />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-foreground mb-2">
                      Message *
                    </label>
                    <Textarea id="message" required value={formData.message} onChange={e => setFormData({
                    ...formData,
                    message: e.target.value
                  })} className="glass-effect border-white/20 dark:border-white/10 focus:border-neon-blue focus:ring-neon-blue resize-none" rows={6} disabled={isSubmitting} placeholder="Tell us about your project..." />
                  </div>

                  <Button type="submit" disabled={isSubmitting} className="w-full px-8 py-6 text-lg font-semibold bg-gradient-to-r from-neon-blue to-neon-purple hover:from-neon-purple hover:to-neon-pink transition-all duration-300 glow-effect hover:scale-105 transform disabled:opacity-50 disabled:cursor-not-allowed">
                    {isSubmitting ? 'Sending...' : 'Send Message'}
                    <Send className="ml-2 h-5 w-5" />
                  </Button>
                </form>
              </div>

              {/* Contact Information */}
              <div className="space-y-8">
                <div className="glass-effect rounded-2xl p-8 ">
                  <h3 className="text-2xl font-semibold text-foreground mb-6">Contact Information</h3>
                  <div className="space-y-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-neon-blue to-neon-purple rounded-lg flex items-center justify-center">
                        <Mail className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">Email</h4>
                        <p className="text-muted-foreground">papayagenie@gmail.com</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-neon-purple to-neon-pink rounded-lg flex items-center justify-center">
                        <Phone className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">Phone</h4>
                        <p className="text-muted-foreground">+91 9990914484</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-neon-pink to-neon-blue rounded-lg flex items-center justify-center">
                        <MapPin className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-foreground">Location</h4>
                        <p className="text-muted-foreground">Delhi, India</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="glass-effect rounded-2xl p-8">
                  <h3 className="text-xl font-semibold text-foreground mb-4">Why Choose Us?</h3>
                  <ul className="space-y-3">
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-neon-blue rounded-full"></div>
                      <span className="text-muted-foreground">24/7 Support & Maintenance</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-neon-purple rounded-full"></div>
                      <span className="text-muted-foreground">Cutting-edge Technologies</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-neon-pink rounded-full"></div>
                      <span className="text-muted-foreground">Custom Solutions</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-neon-green rounded-full"></div>
                      <span className="text-muted-foreground">Fast Delivery</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-white/20 dark:border-white/10">
          <div className="max-w-7xl mx-auto text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-neon-blue to-neon-purple rounded-lg flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-space font-bold bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
                PapayaGenie
              </span>
            </div>
            <p className="text-muted-foreground mb-4">
              Building the future, one digital experience at a time.
            </p>
            <p className="text-sm text-muted-foreground">© 2025 PapayaGenie. All rights reserved.</p>
          </div>
        </footer>

        {/* Back to Top Button */}
        <Button onClick={scrollToTop} className="fixed bottom-6 right-6 z-50 w-12 h-12 p-0 bg-gradient-to-r from-neon-blue to-neon-purple hover:from-neon-purple hover:to-neon-pink transition-all duration-300 glow-effect hover:scale-110 transform rounded-full">
          <ArrowUp className="h-6 w-6 text-white" />
        </Button>
      </div>
    </>;
};
export default Index;